Server Protocol Bridge 2.6 - source package
Generated: 2026-11-23 01:40:18 UTC

================================================================
English
================================================================

1. Where to get the released program

   This archive contains no binaries and no downloads directory.  The
   release files are hosted by the release site:

     Release page
       https://848488489-ff.github.io/ServerProtocolBridge/

     Windows program
       https://848488489-ff.github.io/ServerProtocolBridge/downloads/Server%20Protocol%20Bridge.exe

   Linux program (x86_64, glibc 2.36+)
     https://848488489-ff.github.io/ServerProtocolBridge/downloads/Server%20Protocol%20Bridge-linux-x86_64

     Source archive ServerProtocolBridge-2.6-source.zip
       https://848488489-ff.github.io/ServerProtocolBridge/downloads/ServerProtocolBridge-2.6-source.zip

   The site's api/version.json is the authoritative manifest:
     version        release number
     file_size      size of the program in bytes
     source_size    size of this archive in bytes


2. Layout

   procedure/    Python application source.
   web/          Source of the static release page.
   LICENSE       Licence text (Unlicense, public-domain dedication).
   README.txt    This file.
   SOURCE-MANIFEST.json  SHA-256 of every file.


3. Running procedure

   Python 3.10 or newer, then:
       py -3 -m pip install -r requirements.txt
       py -3 main.py

   On Linux / macOS use python3 instead of py, or run:
       sh start.sh

   PyInstaller cannot cross-compile, so each platform builds its own binary:

   Linux / macOS (optional):
       sh tools/build.sh

   Windows (optional):
       py -3 -m pip install -r requirements-build.txt
       py -3 tools/build.py

   On Windows with WSL2, build the Linux binary from the repository root:
       powershell -ExecutionPolicy Bypass -File toolsuild_wsl.ps1
   (the first run creates a virtual environment inside WSL and installs the
   dependencies; the result is dist/Server Protocol Bridge, a Linux ELF)

   Android native APK (requires Android Studio):
      android/ is an Android Studio Gradle project that embeds Python via
      Chaquopy; the control panel is shown in a built-in WebView.  Open
      android/ and build the APK; see android/README.md.

   Third-party components and their full licence texts are in
   THIRD_PARTY_NOTICES.txt.  Regenerate that file with:
       py -3 tools/collect_licenses.py


4. Running web

   web/index.html is the static release page.  Open it directly in a browser,
   or serve the folder with any static file server.  Release data comes from
   api/version.json, FAQ content from api/faq.json, and the API reference is
   api/index.html.

   The packaged api/version.json omits source_size and
   source_updated on purpose: an archive cannot contain its own final hash.
   The live site's api/version.json is authoritative for those fields.


5. Deliberately not included

   - build/, dist/, *.exe and other release binaries
   - web's downloads/ directory (deployment content that only the release
     site has; shipping it inside its own source archive would nest the
     package forever)
   - certs/ (local TLS private keys)
   - config.json, logs, caches and __pycache__
   - the standalone admin.html test page

   To export the source package again, run from the repository root:
       py -3 tools/export_source.py


See SOURCE-MANIFEST.json for every file and its SHA-256.
