"""Small shared helpers: path resolution and byte/duration formatting."""

from __future__ import annotations

import os
import sys
from pathlib import Path


def app_dir() -> Path:
    """Directory the program lives in.

    When frozen into an EXE this is the folder containing the executable (the
    place the user double-clicked); when run from source it is the project root.
    """
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def resolve_path(value: str | os.PathLike[str], base: Path | None = None) -> Path:
    """Turn a configured path into an absolute one; relative paths are based
    on ``base`` (the configuration directory by default, so a value such as
    ``certs`` lands in the user's own folder instead of beside the executable)."""
    path = Path(value).expanduser()
    if path.is_absolute():
        return path
    return (base or config_dir()) / path


# Folder name under the per-user data directory; deliberately without spaces.
DATA_FOLDER = 'ServerProtocolBridge'


def is_android() -> bool:
    """True when running under Android (Chaquopy or Termux).

    Detected by several independent signals so the entry point can route to
    the Android WebView path without relying on any single platform value:
    Chaquopy runs CPython on the Android Linux kernel, where ``sys.platform``
    may be either ``'android'`` or ``'linux'``.
    """
    if sys.platform == 'android':
        return True
    if (os.environ.get('ANDROID_ARGUMENT') or os.environ.get('ANDROID_ROOT')
            or os.environ.get('ANDROID_STORAGE')):
        return True
    home = os.environ.get('HOME', '')
    return home.startswith('/data/data/') or home.startswith('/data/user/')


def data_dir() -> Path:
    """The standard per-user data directory of this program (cross-platform).

    Windows: %APPDATA%\\ServerProtocolBridge
    macOS:   ~/Library/Application Support/ServerProtocolBridge
    Linux:   $XDG_DATA_HOME/ServerProtocolBridge (or ~/.local/share/...)
    Android: $HOME/ServerProtocolBridge (Chaquopy sets HOME to the app's
             internal storage directory, which is writable and persists
             until the app is uninstalled)

    Files that belong to the user rather than to the installation (the account
    list, for one) live here: moving or reinstalling the EXE cannot lose them.
    The SPB_DATA_DIR environment variable overrides the location outright,
    which tests and portable installs use.
    """
    override = (os.environ.get('SPB_DATA_DIR') or '').strip()
    if override:
        return Path(override).expanduser()
    if is_android():
        return Path.home() / DATA_FOLDER
    if os.name == 'nt':
        base = (os.environ.get('APPDATA') or '').strip()
        root = Path(base) if base else Path.home() / 'AppData' / 'Roaming'
    elif sys.platform == 'darwin':
        root = Path.home() / 'Library' / 'Application Support'
    else:
        base = (os.environ.get('XDG_DATA_HOME') or '').strip()
        root = Path(base) if base else Path.home() / '.local' / 'share'
    return root / DATA_FOLDER


def config_dir() -> Path:
    """The folder holding this program's user configuration.

    Always per-user, never beside the executable.  Writing ``config.json``
    next to the EXE fails outright in Program Files, where that folder is
    read-only, and the settings were wiped by every reinstall and every
    update that replaced the directory.  Configuration is user data, so it
    belongs with the account file in the per-user folder.
    """
    return data_dir()


def human_bytes(value: float) -> str:
    """Format a byte count into a human-readable string."""
    value = float(value)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if abs(value) < 1024 or unit == 'TB':
            if unit == 'B':
                return '%d B' % int(value)
            return '%.2f %s' % (value, unit)
        value /= 1024.0
    return '%.2f TB' % value


def human_duration(seconds: float) -> str:
    """Format a number of seconds as hours:minutes:seconds."""
    seconds = int(max(0, seconds))
    hours, rest = divmod(seconds, 3600)
    minutes, secs = divmod(rest, 60)
    if hours:
        return '%d:%02d:%02d' % (hours, minutes, secs)
    return '%d:%02d' % (minutes, secs)
