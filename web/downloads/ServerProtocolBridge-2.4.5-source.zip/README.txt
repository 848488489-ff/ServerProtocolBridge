Server Protocol Bridge 2.4.5 - 源码包 / source package
生成时间 / Generated: 2026-11-19 11:20:51 UTC

================================================================
一、中文说明
================================================================

1. 怎么获取发布的程序

   本源码包不包含任何可执行文件, 也不包含网站的 downloads 目录。
   发布文件(Windows 程序、源码压缩包)托管在发布站点上, 按下面的地址下载:

     发布页面
       https://banbengengxinjiancha.pages.dev/

     Windows 程序
       https://banbengengxinjiancha.pages.dev/downloads/Server%20Protocol%20Bridge.exe

      Linux 程序 (x86_64, glibc 2.36+)
       https://banbengengxinjiancha.pages.dev/downloads/Server%20Protocol%20Bridge-linux-x86_64

     源码压缩包 ServerProtocolBridge-2.4.5-source.zip
       https://banbengengxinjiancha.pages.dev/downloads/ServerProtocolBridge-2.4.5-source.zip

   发布站点的 api/version.json 是权威清单:
     version        版本号
     file_size      程序的字节数
     source_size    源码压缩包的字节数


2. 目录结构

   procedure/    Python 应用源码。
   web/          静态发布/下载页面的源码。
   LICENSE       许可证全文(Unlicense, 公有领域)。
   README.txt    本说明。
   SOURCE-MANIFEST.json  每个文件的 SHA-256。


3. 运行 procedure

   准备 Python 3.10 或更高版本, 然后:
       py -3 -m pip install -r requirements.txt
       py -3 main.py

   Linux / macOS 用 python3 代替 py, 或直接运行:
       sh start.sh

   PyInstaller 不支持交叉编译, 每个平台只生成自己的二进制:

   Linux / macOS 打包(可选):
       sh tools/build.sh

   Windows 打包(可选):
       py -3 -m pip install -r requirements-build.txt
       py -3 tools/build.py

   Windows + WSL2 想构建 Linux 版本时, 在仓库根目录运行:
       powershell -ExecutionPolicy Bypass -File toolsuild_wsl.ps1
   (首次运行会在 WSL 内自动创建虚拟环境并安装依赖; 结果为
   dist/Server Protocol Bridge, 是 Linux ELF 可执行文件)

   Android 原生 APK(需要 Android Studio):
      android/ 目录是 Android Studio Gradle 项目, 用 Chaquopy 嵌入
      Python, 控制面板由内置 WebView 显示。打开 android/ 后构建
      APK; 详见 android/README.md。

   第三方组件及其完整许可证文本见 THIRD_PARTY_NOTICES.txt,
   可用下面的命令重新生成:
       py -3 tools/collect_licenses.py


4. 运行 web

   web/index.html 是静态发布页面, 可以直接用浏览器打开, 也可以用任意
   静态文件服务器托管整个目录。发布数据来自 api/version.json, 常见问题
   来自 api/faq.json, 接口文档是 api/index.html。

   包内 api/version.json 故意省略了 source_size 与
   source_updated: 压缩包无法包含自己的最终哈希。这两个字段以线上站点
   的 api/version.json 为准。


5. 本包故意不包含的内容

   - build/、dist/、*.exe 等发布产物
   - web 的 downloads/ 目录(发布站点才有的部署内容, 放进自己的源码包
     会无限套娃)
   - certs/(本地 TLS 私钥)
   - config.json、日志、缓存、__pycache__
   - 独立的 admin.html 测试页面

   要重新导出源码包, 在仓库根目录运行:
       py -3 tools/export_source.py


================================================================
二、English
================================================================

1. Where to get the released program

   This archive contains no binaries and no downloads directory.  The
   release files are hosted by the release site:

     Release page
       https://banbengengxinjiancha.pages.dev/

     Windows program
       https://banbengengxinjiancha.pages.dev/downloads/Server%20Protocol%20Bridge.exe

   Linux program (x86_64, glibc 2.36+)
     https://banbengengxinjiancha.pages.dev/downloads/Server%20Protocol%20Bridge-linux-x86_64

     Source archive ServerProtocolBridge-2.4.5-source.zip
       https://banbengengxinjiancha.pages.dev/downloads/ServerProtocolBridge-2.4.5-source.zip

   The site's api/version.json is the authoritative manifest:
     version        release number
     file_size      size of the program in bytes
     source_size    size of this archive in bytes


2. Layout

   procedure/    Python application source.
   web/          Source of the static release page.
   LICENSE       Licence text (Unlicense, public-domain dedication).
   README.txt    This file.
   SOURCE-MANIFEST.json  SHA-256 of every file.


3. Running procedure

   Python 3.10 or newer, then:
       py -3 -m pip install -r requirements.txt
       py -3 main.py

   On Linux / macOS use python3 instead of py, or run:
       sh start.sh

   PyInstaller cannot cross-compile, so each platform builds its own binary:

   Linux / macOS (optional):
       sh tools/build.sh

   Windows (optional):
       py -3 -m pip install -r requirements-build.txt
       py -3 tools/build.py

   On Windows with WSL2, build the Linux binary from the repository root:
       powershell -ExecutionPolicy Bypass -File toolsuild_wsl.ps1
   (the first run creates a virtual environment inside WSL and installs the
   dependencies; the result is dist/Server Protocol Bridge, a Linux ELF)

   Android native APK (requires Android Studio):
      android/ is an Android Studio Gradle project that embeds Python via
      Chaquopy; the control panel is shown in a built-in WebView.  Open
      android/ and build the APK; see android/README.md.

   Third-party components and their full licence texts are in
   THIRD_PARTY_NOTICES.txt.  Regenerate that file with:
       py -3 tools/collect_licenses.py


4. Running web

   web/index.html is the static release page.  Open it directly in a browser,
   or serve the folder with any static file server.  Release data comes from
   api/version.json, FAQ content from api/faq.json, and the API reference is
   api/index.html.

   The packaged api/version.json omits source_size and
   source_updated on purpose: an archive cannot contain its own final hash.
   The live site's api/version.json is authoritative for those fields.


5. Deliberately not included

   - build/, dist/, *.exe and other release binaries
   - web's downloads/ directory (deployment content that only the release
     site has; shipping it inside its own source archive would nest the
     package forever)
   - certs/ (local TLS private keys)
   - config.json, logs, caches and __pycache__
   - the standalone admin.html test page

   To export the source package again, run from the repository root:
       py -3 tools/export_source.py


See SOURCE-MANIFEST.json for every file and its SHA-256.
